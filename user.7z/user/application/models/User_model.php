<?php
 
 
class User_model extends CI_Model{
 
    public function __construct()
    {
        $this->load->database();
        $this->load->helper('url');
    }
 
    /*
        Get all the records from the database
    */
    public function get_all()
    {
        $user = $this->db->get("user")->result();
        return $user;
    }
 
    /*
        Store the record in the database
    */
    public function store()
    {    
        $data = [
            'FirstName'        => $this->input->post('FirstName'),
            'LastName'        => $this->input->post('LastName'),
            'Email' => $this->input->post('Email')
        ];
 
        $result = $this->db->insert('user', $data);
        return $result;
    }
 
    /*
        Get an specific record from the database
    */
    public function get($id)
    {
        $user = $this->db->get_where('user', ['id' => $id ])->row();
        return $user;
    }
 
 
    /*
        Update or Modify a record in the database
    */
    public function update($id) 
    {
        $data = [
            'FirstName'        => $this->input->post('FirstName'),
            'LastName'        => $this->input->post('LastName'),
            'Email' => $this->input->post('Email')
        ];
 
        $result = $this->db->where('id',$id)->update('user',$data);
        return $result;
                 
    }
 
    /*
        Destroy or Remove a record in the database
    */
    public function delete($id)
    {
        $result = $this->db->delete('user', array('id' => $id));
        return $result;
    }
     
}
?>