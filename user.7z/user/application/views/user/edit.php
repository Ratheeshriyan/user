<h2 class="text-center mt-5 mb-3"><?php echo $title;?></h2>
<div class="card">
    <div class="card-header">
        <a class="btn btn-outline-info float-right" href="<?php echo base_url('user/');?>"> 
            View All users
        </a>
    </div>
    <div class="card-body">
        <?php if ($this->session->flashdata('errors')) {?>
            <div class="alert alert-danger">
                <?php echo $this->session->flashdata('errors'); ?>
            </div>
        <?php } ?>
 
        <form action="<?php echo base_url('user/update/' . $user->id);?>" method="POST">
            <input type="hidden" name="_method" value="PUT">
            <div class="form-group">
                <label for="name">FirstName</label>
                <input
                    type="text"
                    class="form-control"
                    id="FirstName"
                    name="FirstName"
                    value="<?php echo $user->FirstName;?>">
            </div>
            <div class="form-group">
                <label for="LastName">LastName</label>
                <input
                    type="text"
                    class="form-control"
                    id="LastName"
                    name="LastName"
                    value="<?php echo $user->LastName;?>">
            </div>
            <div class="form-group">
                <label for="name">Email</label>
                <input
                    type="text"
                    class="form-control"
                    id="Email"
                    name="Email"
                    value="<?php echo $user->Email;?>">
            </div>
            <div class="form-group">

                <label for="Password">Password</label>
                <input type="password" class="form-control" id="password" name="password" value="<?php echo $user->Password;?>">

            </div>
          
            <button type="submit" class="btn btn-outline-primary">Save user</button>
        </form>
       
    </div>
</div>