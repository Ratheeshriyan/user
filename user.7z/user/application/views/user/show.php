<h2 class="text-center mt-5 mb-3"><?php echo $title;?></h2>
<div class="card">
    <div class="card-header">
        <a class="btn btn-outline-info float-right" href="<?php echo base_url('user/');?>"> 
            View All users
        </a>
    </div>
    <div class="card-body">
       <b class="text-muted">FirstName:</b>
       <p><?php echo $user->FirstName;?></p>
       <b class="text-muted">LastName:</b>
       <p><?php echo $user->LastName;?></p>
       <b class="text-muted">Email:</b>
       <p><?php echo $user->Email;?></p>
    </div>
</div>