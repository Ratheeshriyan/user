<h2 class="text-center mt-5 mb-3"><?php echo $title; ?></h2>
<div class="card">
    <div class="card-header">
        <a class="btn btn-outline-info float-right" href="<?php echo base_url('user');?>"> 
            View All Users
        </a>
    </div>
    <div class="card-body">
        <?php if ($this->session->flashdata('errors')) {?>
            <div class="alert alert-danger">
                <?php echo $this->session->flashdata('errors'); ?>
            </div>
        <?php } ?>
        <form action="<?php echo base_url('user/store');?>" method="POST">
            <div class="form-group">
                <label for="name">FirstName</label>
                <input type="text" class="form-control" id="name" name="FirstName">
            </div>
            <div class="form-group">
                <label for="name">LastName</label>
                <input type="text" class="form-control" id="Lname" name="LastName">
            </div>
            <div class="form-group">
                <label for="name">Email</label>
                <input type="text" class="form-control" id="Email" name="Email">
            </div>
            <div class="form-group">
                <label for="name">Password</label>
                <input type="password" class="form-control" id="password" name="password">
            </div>
          
            <button type="submit" class="btn btn-outline-primary">Save user</button>
        </form>
       
    </div>
</div>