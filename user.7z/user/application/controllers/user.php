<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller {
 
   public function __construct() {
      parent::__construct(); 
      $this->load->library('form_validation');
      $this->load->library('session');
      $this->load->model('User_model', 'user');
 
   }
 
   /*
      Display all records in page
   */
  public function index()
  {
    $data['title'] = "List User Page";
    $this->load->view('layout/header');       
    $this->load->view('user/index',$data);
    $this->load->view('layout/footer');
  }
 
  /*
 
    Display a record
  */
  public function show($id)
  {
    $data['user'] = $this->user->get($id);
    $data['title'] = "View User page";
    $this->load->view('layout/header');
    $this->load->view('user/show', $data);
    $this->load->view('layout/footer'); 
  }
 
  /*
    Create a record page
  */
  public function create()
  {
    $data['title'] = "Create Users";
    $this->load->view('layout/header');
    $this->load->view('user/create',$data);
    $this->load->view('layout/footer');     
  }
 
  /*
    Save the submitted record
  */
  public function store()
  {
    $this->form_validation->set_rules('name', 'Name', 'required');
    $this->form_validation->set_rules('description', 'Description', 'required');
 
    if (!$this->form_validation->run())
    {
        $this->session->set_flashdata('errors', validation_errors());
        redirect(base_url('user/create'));
    }
    else
    {
       $this->user->store();
       $this->session->set_flashdata('success', "Saved Successfully!");
       redirect(base_url('user'));
    }
 
  }
 
  /*
    Edit a record page
  */
  public function edit($id)
  {
    $data['users'] = $this->user->get($id);
    $data['title'] = "Edit user";
    $this->load->view('layout/header');
    $this->load->view('user/edit', $data);
    $this->load->view('layout/footer');     
  }
 
  /*
    Update the submitted record
  */
  public function update($id)
  {
    $this->form_validation->set_rules('name', 'Name', 'required');
    $this->form_validation->set_rules('description', 'Description', 'required');
 
    if (!$this->form_validation->run())
    {
        $this->session->set_flashdata('errors', validation_errors());
        redirect(base_url('user/edit/' . $id));
    }
    else
    {
       $this->user->update($id);
       $this->session->set_flashdata('success', "Updated Successfully!");
       redirect(base_url('user'));
    }
 
  }
 
  /*
    Delete a record
  */
  public function delete($id)
  {
    $item = $this->user->delete($id);
    $this->session->set_flashdata('success', "Deleted Successfully!");
    redirect(base_url('user'));
  }
 
 
}